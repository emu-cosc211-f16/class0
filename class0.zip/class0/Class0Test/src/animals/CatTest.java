package animals;

import static org.junit.Assert.*;

import org.junit.Test;

public class CatTest {

	@Test
	public void testCat(){
		Cat cat = new Cat("Meowzart");
		Cat cat2 = new Cat("Meowzart");
		
		assertEquals(cat, cat2);
		assertSame(cat, cat2);

		assertSame(cat, cat);
	}
	
	//make this test pass!
	@Test
	public void testCatName(){
		String name = "Purrsephone";
		Cat cat = new Cat(name);
		assertEquals(name, cat.getName());
	}
	
	@Test
	public void testCatAge(){
		//Change the constructor of the Cat class to take an integer
		//representing the cats age.
		
		//then, test that the cats age will be returned by a method, getAge()
		fail("Not yet implemented! Create some tests to test the cats age!");
	}
}

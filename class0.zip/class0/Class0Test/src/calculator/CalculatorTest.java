package calculator;
import static org.junit.Assert.*;
import org.junit.Test;

public class CalculatorTest {
	
	@Test
	public void testCalculatorAdd() {
		assertEquals(4, Calculator.add(2,2));
		assertEquals(-13, Calculator.add(-20, 7));
		assertEquals(1000, Calculator.add(999, 1));
	}
	
	@Test
	public void testCalculatorSubtract(){
		assertEquals(1, Calculator.subtract(5, 4));
		assertEquals(30, Calculator.subtract(50, 20));
	}
	
	@Test
	public void testIsGreaterThan(){
		assertTrue(Calculator.isGreaterThan(50, 40));
		assertFalse(Calculator.isGreaterThan(50, -1));
	}
	
	//create a test for the isLessThan method in Calculator!
	//See it fail first, then implement code to make it pass!
	
}

package calculator;

public class Calculator {

	public static int add(int number1, int number2){
		return 0;
	}
	
	public static int subtract(int numberToSubtractFrom, int numberToSubtract){
		return 1;
	}
	
	public static boolean isGreaterThan(int numberToCompare, int numberToCompareTo){
		return false;
	}
}
